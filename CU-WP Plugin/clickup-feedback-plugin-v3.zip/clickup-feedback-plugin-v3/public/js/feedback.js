let feedbackMode = false;
let selectedElement = null;

const btn = document.createElement('button');
btn.innerText = 'Feedback';
btn.id = 'cuf-feedback-btn';

document.body.appendChild(btn);

const modal = document.createElement('div');
modal.id = 'cuf-modal';
modal.innerHTML = `
    <div class="cuf-modal-content">
        <h3>Submit Feedback</h3>

        <input type="email" id="cuf-email" placeholder="Your Email">

        <textarea id="cuf-comment" placeholder="Enter feedback"></textarea>

        <div class="cuf-actions">
            <button id="cuf-submit">Submit</button>
            <button id="cuf-cancel">Cancel</button>
        </div>
    </div>
`;

document.body.appendChild(modal);

btn.addEventListener('click', () => {

    feedbackMode = !feedbackMode;

    btn.innerText = feedbackMode
        ? 'Click Anywhere'
        : 'Feedback';

});

document.addEventListener('click', function(e) {

    if (!feedbackMode) return;

    if (
        e.target.id === 'cuf-feedback-btn' ||
        e.target.closest('#cuf-modal')
    ) return;

    e.preventDefault();
    e.stopPropagation();

    selectedElement = e.target;

    selectedElement.classList.add('cuf-highlight');

    modal.style.display = 'flex';

}, true);

document.getElementById('cuf-cancel').addEventListener('click', () => {

    modal.style.display = 'none';

    if (selectedElement) {
        selectedElement.classList.remove('cuf-highlight');
    }

    feedbackMode = false;
    btn.innerText = 'Feedback';
});

document.getElementById('cuf-submit').addEventListener('click', () => {

    const email = document.getElementById('cuf-email').value;
    const comment = document.getElementById('cuf-comment').value;

    if (!email || !comment) {
        alert('Please complete all fields.');
        return;
    }

    const payload = {
        email: email,
        comment: comment,
        url: window.location.href,
        selector: getSelector(selectedElement),
        browser: navigator.userAgent
    };

    fetch(cufData.restUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': cufData.nonce
        },
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {

        alert(data.message || 'Feedback sent.');

        modal.style.display = 'none';

        document.getElementById('cuf-email').value = '';
        document.getElementById('cuf-comment').value = '';

        if (selectedElement) {
            selectedElement.classList.remove('cuf-highlight');
        }

        feedbackMode = false;
        btn.innerText = 'Feedback';

    })
    .catch(err => {
        console.error(err);
        alert('Error sending feedback.');
    });

});

function getSelector(el) {

    if (!el) return '';

    if (el.id) {
        return '#' + el.id;
    }

    let path = [];

    while (el && el.nodeType === Node.ELEMENT_NODE) {

        let selector = el.nodeName.toLowerCase();

        if (el.className) {
            selector += '.' + el.className
                .trim()
                .replace(/\s+/g, '.');
        }

        path.unshift(selector);

        el = el.parentNode;
    }

    return path.join(' > ');
}
