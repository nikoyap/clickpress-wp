<?php

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {

    register_rest_route('cuf/v1', '/feedback', [
        'methods'  => 'POST',
        'callback' => 'cuf_submit_feedback',
        'permission_callback' => '__return_true'
    ]);

});

function cuf_submit_feedback($request) {

    $params = $request->get_json_params();

    $email = sanitize_email($params['email'] ?? '');
    $comment = sanitize_text_field($params['comment'] ?? '');
    $url = esc_url_raw($params['url'] ?? '');
    $selector = sanitize_text_field($params['selector'] ?? '');
    $browser = sanitize_text_field($params['browser'] ?? '');

    $api_key = get_option('cuf_api_key');
    $list_id = get_option('cuf_list_id');

    if (empty($api_key) || empty($list_id)) {

        return new WP_REST_Response([
            'success' => false,
            'message' => 'Plugin settings are incomplete.'
        ], 400);

    }

    $payload = [
        'name' => $email ?: 'Website Feedback',
        'description' =>
            "Email: {$email}\n\n" .
            "Comment: {$comment}\n\n" .
            "Page URL: {$url}\n\n" .
            "Element: {$selector}\n\n" .
            "Browser: {$browser}"
    ];

    $response = wp_remote_post(
        "https://api.clickup.com/api/v2/list/{$list_id}/task",
        [
            'headers' => [
                'Authorization' => $api_key,
                'Content-Type'  => 'application/json'
            ],
            'body' => json_encode($payload)
        ]
    );

    if (is_wp_error($response)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $response->get_error_message()
        ], 500);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Feedback submitted successfully.'
    ], 200);
}
