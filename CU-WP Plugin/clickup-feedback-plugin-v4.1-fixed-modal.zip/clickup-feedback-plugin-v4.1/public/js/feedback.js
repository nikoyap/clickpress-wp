let feedbackMode = false;
let selectedElement = null;

const btn = document.createElement('button');
btn.innerText = 'Feedback';
btn.id = 'cuf-feedback-btn';

document.body.appendChild(btn);

btn.addEventListener('click', () => {

    feedbackMode = !feedbackMode;

    btn.innerText = feedbackMode
        ? 'Click Any Element'
        : 'Feedback';
});

document.addEventListener('click', function(e) {

    if (!feedbackMode) return;

    // Ignore modal clicks and button clicks
    if (
        e.target.closest('#cuf-modal') ||
        e.target.id === 'cuf-feedback-btn'
    ) {
        return;
    }

    e.preventDefault();
    e.stopPropagation();

    selectedElement = e.target;

    selectedElement.classList.add('cuf-highlight');

    // Disable feedback mode after selection
    feedbackMode = false;
    btn.innerText = 'Feedback';

    openFeedbackModal();

}, true);

function openFeedbackModal() {

    // Prevent duplicate modals
    if (document.getElementById('cuf-modal')) {
        return;
    }

    const modal = document.createElement('div');

    modal.id = 'cuf-modal';

    modal.innerHTML = `
        <div class="cuf-modal-content">
            <h3>Send Feedback</h3>

            <input
                type="email"
                id="cuf-email"
                placeholder="Your email"
            >

            <textarea
                id="cuf-comment"
                placeholder="Enter feedback"
            ></textarea>

            <label class="cuf-checkbox">
                <input
                    type="checkbox"
                    id="cuf-screenshot"
                    checked
                >
                Include Screenshot
            </label>

            <div class="cuf-actions">
                <button id="cuf-submit">Submit</button>
                <button id="cuf-cancel">Cancel</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    document.getElementById('cuf-cancel').onclick = closeModal;

    document.getElementById('cuf-submit').onclick = async () => {

        const email = document.getElementById('cuf-email').value.trim();
        const comment = document.getElementById('cuf-comment').value.trim();
        const includeScreenshot = document.getElementById('cuf-screenshot').checked;

        if (!email || !comment) {
            alert('Please complete all fields.');
            return;
        }

        let screenshot = '';

        try {

            if (includeScreenshot) {

                const canvas = await html2canvas(document.body, {
                    useCORS: true,
                    allowTaint: true
                });

                screenshot = canvas.toDataURL('image/png');
            }

        } catch (err) {
            console.error('Screenshot failed:', err);
        }

        const payload = {
            email,
            comment,
            screenshot,
            url: window.location.href,
            selector: getSelector(selectedElement),
            browser: navigator.userAgent
        };

        fetch(cufData.restUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': cufData.nonce
            },
            body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(data => {

            alert(data.message || 'Feedback submitted.');

            closeModal();

        })
        .catch(err => {

            console.error(err);

            alert('Error submitting feedback.');
        });
    };
}

function closeModal() {

    const modal = document.getElementById('cuf-modal');

    if (modal) {
        modal.remove();
    }

    if (selectedElement) {
        selectedElement.classList.remove('cuf-highlight');
    }
}

function getSelector(el) {

    if (el.id) {
        return '#' + el.id;
    }

    let path = [];

    while (el && el.nodeType === Node.ELEMENT_NODE) {

        let selector = el.nodeName.toLowerCase();

        if (el.className) {

            selector += '.' + el.className
                .trim()
                .replace(/\s+/g, '.');
        }

        path.unshift(selector);

        el = el.parentNode;
    }

    return path.join(' > ');
}
