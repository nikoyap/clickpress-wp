
let feedbackMode = false;
let selectedElement = null;

const btn = document.createElement('button');
btn.innerText = 'Feedback';
btn.id = 'cuf-feedback-btn';

document.body.appendChild(btn);

btn.addEventListener('click', () => {

    feedbackMode = !feedbackMode;

    btn.innerText = feedbackMode
        ? 'Click Any Element'
        : 'Feedback';
});

document.addEventListener('click', function(e) {

    if (!feedbackMode) return;

    if (e.target.id === 'cuf-feedback-btn') return;

    e.preventDefault();
    e.stopPropagation();

    selectedElement = e.target;
    selectedElement.classList.add('cuf-highlight');

    openFeedbackModal();

}, true);

function openFeedbackModal() {

    const modal = document.createElement('div');

    modal.id = 'cuf-modal';

    modal.innerHTML = `
        <div class="cuf-modal-content">
            <h3>Send Feedback</h3>

            <input type="email" id="cuf-email" placeholder="Your email">

            <textarea id="cuf-comment" placeholder="Enter feedback"></textarea>

            <label class="cuf-checkbox">
                <input type="checkbox" id="cuf-screenshot" checked>
                Include Screenshot
            </label>

            <div class="cuf-actions">
                <button id="cuf-submit">Submit</button>
                <button id="cuf-cancel">Cancel</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    document.getElementById('cuf-cancel').onclick = () => {
        closeModal();
    };

    document.getElementById('cuf-submit').onclick = async () => {

        const email = document.getElementById('cuf-email').value;
        const comment = document.getElementById('cuf-comment').value;
        const includeScreenshot = document.getElementById('cuf-screenshot').checked;

        let screenshot = '';

        if (includeScreenshot) {

            const canvas = await html2canvas(document.body);

            screenshot = canvas.toDataURL('image/png');
        }

        const payload = {
            email,
            comment,
            screenshot,
            url: window.location.href,
            selector: getSelector(selectedElement),
            browser: navigator.userAgent
        };

        fetch(cufData.restUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': cufData.nonce
            },
            body: JSON.stringify(payload)
        })
        .then(res => res.json())
        .then(data => {
            alert(data.message);
            closeModal();
        })
        .catch(err => {
            console.error(err);
            alert('Error submitting feedback');
        });
    };
}

function closeModal() {

    const modal = document.getElementById('cuf-modal');

    if (modal) modal.remove();

    if (selectedElement) {
        selectedElement.classList.remove('cuf-highlight');
    }

    feedbackMode = false;

    btn.innerText = 'Feedback';
}

function getSelector(el) {

    if (el.id) {
        return '#' + el.id;
    }

    let path = [];

    while (el && el.nodeType === Node.ELEMENT_NODE) {

        let selector = el.nodeName.toLowerCase();

        if (el.className) {
            selector += '.' + el.className.trim().replace(/\s+/g, '.');
        }

        path.unshift(selector);

        el = el.parentNode;
    }

    return path.join(' > ');
}
