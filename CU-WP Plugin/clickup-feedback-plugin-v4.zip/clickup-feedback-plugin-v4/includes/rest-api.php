
<?php

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {

    register_rest_route('cuf/v1', '/feedback', [
        'methods' => 'POST',
        'callback' => 'cuf_submit_feedback',
        'permission_callback' => '__return_true'
    ]);
});

function cuf_submit_feedback($request) {

    $params = $request->get_json_params();

    $email = sanitize_email($params['email'] ?? '');
    $comment = sanitize_text_field($params['comment'] ?? '');
    $url = esc_url_raw($params['url'] ?? '');
    $selector = sanitize_text_field($params['selector'] ?? '');
    $browser = sanitize_text_field($params['browser'] ?? '');
    $screenshot = $params['screenshot'] ?? '';

    $api_key = get_option('cuf_api_key');
    $list_id = get_option('cuf_list_id');

    if (empty($api_key) || empty($list_id)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Plugin settings incomplete.'
        ], 400);
    }

    $payload = [
        'name' => $email,
        'description' =>
            "Email: {$email}\n\n" .
            "Comment: {$comment}\n\n" .
            "Page URL: {$url}\n\n" .
            "Element: {$selector}\n\n" .
            "Browser: {$browser}"
    ];

    $response = wp_remote_post(
        "https://api.clickup.com/api/v2/list/{$list_id}/task",
        [
            'headers' => [
                'Authorization' => $api_key,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($payload)
        ]
    );

    if (is_wp_error($response)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $response->get_error_message()
        ], 500);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    $task_id = $body['id'] ?? '';

    if (!empty($screenshot) && !empty($task_id)) {

        $upload_dir = wp_upload_dir();

        $image_data = explode(',', $screenshot);

        if (isset($image_data[1])) {

            $decoded = base64_decode($image_data[1]);

            $filename = 'cuf-screenshot-' . time() . '.png';
            $filepath = $upload_dir['path'] . '/' . $filename;

            file_put_contents($filepath, $decoded);

            $file = curl_file_create($filepath, 'image/png', $filename);

            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, "https://api.clickup.com/api/v2/task/{$task_id}/attachment");
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Authorization: {$api_key}"
            ]);
            curl_setopt($ch, CURLOPT_POSTFIELDS, [
                'attachment' => $file
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            curl_exec($ch);
            curl_close($ch);
        }
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Feedback submitted successfully.'
    ], 200);
}
