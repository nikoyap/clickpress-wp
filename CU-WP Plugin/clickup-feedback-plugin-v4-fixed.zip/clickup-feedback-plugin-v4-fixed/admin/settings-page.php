<?php

if (!defined('ABSPATH')) exit;

add_action('admin_menu', 'cuf_admin_menu');

function cuf_admin_menu() {

    add_menu_page(
        'ClickUp Feedback',
        'ClickUp Feedback',
        'manage_options',
        'cuf-settings',
        'cuf_settings_page',
        'dashicons-feedback',
        30
    );
}

add_action('admin_init', 'cuf_register_settings');

function cuf_register_settings() {

    register_setting(
        'cuf_settings_group',
        'cuf_api_key'
    );

    register_setting(
        'cuf_settings_group',
        'cuf_list_id'
    );
}

function cuf_settings_page() {
?>

<div class="wrap">
    <h1>ClickUp Feedback Settings</h1>

    <form method="post" action="options.php">

        <?php
            settings_fields('cuf_settings_group');
            do_settings_sections('cuf_settings_group');
        ?>

        <table class="form-table">

            <tr>
                <th scope="row">ClickUp API Key</th>
                <td>
                    <input
                        type="password"
                        name="cuf_api_key"
                        value="<?php echo esc_attr(get_option('cuf_api_key')); ?>"
                        class="regular-text"
                    >
                </td>
            </tr>

            <tr>
                <th scope="row">ClickUp List ID</th>
                <td>
                    <input
                        type="text"
                        name="cuf_list_id"
                        value="<?php echo esc_attr(get_option('cuf_list_id')); ?>"
                        class="regular-text"
                    >
                </td>
            </tr>

        </table>

        <?php submit_button(); ?>

    </form>
</div>

<?php
}
