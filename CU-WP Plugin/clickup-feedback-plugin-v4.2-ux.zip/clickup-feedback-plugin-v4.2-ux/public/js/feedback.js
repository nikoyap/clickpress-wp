let feedbackMode = false;
let selectedElement = null;
let submitBtnRef = null;

const btn = document.createElement('button');
btn.innerText = 'Feedback';
btn.id = 'cuf-feedback-btn';
document.body.appendChild(btn);

btn.addEventListener('click', () => {
    feedbackMode = !feedbackMode;
    btn.innerText = feedbackMode ? 'Click Element' : 'Feedback';
});

document.addEventListener('click', function(e) {

    if (!feedbackMode) return;

    if (e.target.id === 'cuf-feedback-btn' || e.target.closest('#cuf-modal')) return;

    e.preventDefault();
    e.stopPropagation();

    selectedElement = e.target;

    feedbackMode = false;
    btn.innerText = 'Feedback';

    openModal();

}, true);

function openModal() {

    if (document.getElementById('cuf-modal')) return;

    const modal = document.createElement('div');
    modal.id = 'cuf-modal';

    modal.innerHTML = `
        <div class="cuf-modal-content">
            <h3>Send Feedback</h3>

            <input type="email" id="cuf-email" placeholder="Email">
            <textarea id="cuf-comment" placeholder="Feedback"></textarea>

            <label>
                <input type="checkbox" id="cuf-shot" checked>
                Screenshot
            </label>

            <div class="cuf-actions">
                <button id="cuf-submit">Submit</button>
                <button id="cuf-cancel">Cancel</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    submitBtnRef = document.getElementById('cuf-submit');

    document.getElementById('cuf-cancel').onclick = closeModal;

    submitBtnRef.onclick = async () => {

        const email = document.getElementById('cuf-email').value.trim();
        const comment = document.getElementById('cuf-comment').value.trim();
        const shot = document.getElementById('cuf-shot').checked;

        if (!email || !comment) {
            alert('Fill all fields');
            return;
        }

        submitBtnRef.disabled = true;
        submitBtnRef.innerText = 'Submitting...';

        let screenshot = '';

        try {

            if (shot) {

                const modalEl = document.getElementById('cuf-modal');
                modalEl.style.display = 'none';

                await new Promise(r => setTimeout(r, 250));

                const canvas = await html2canvas(document.body, {
                    useCORS: true
                });

                screenshot = canvas.toDataURL('image/png');

                modalEl.style.display = 'flex';
            }

        } catch (err) {
            console.error(err);
        }

        fetch(cufData.restUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': cufData.nonce
            },
            body: JSON.stringify({
                email,
                comment,
                screenshot,
                url: window.location.href,
                selector: getSelector(selectedElement),
                browser: navigator.userAgent
            })
        })
        .then(r => r.json())
        .then(res => {
            alert(res.message || 'Done');
            closeModal();
        })
        .catch(err => {
            console.error(err);
            submitBtnRef.disabled = false;
            submitBtnRef.innerText = 'Submit';
        });
    };
}

function closeModal() {

    const m = document.getElementById('cuf-modal');
    if (m) m.remove();

    if (selectedElement) selectedElement.classList.remove('cuf-highlight');
}

function getSelector(el) {
    if (el.id) return '#' + el.id;

    let path = [];
    while (el && el.nodeType === 1) {
        let s = el.nodeName.toLowerCase();
        if (el.className) s += '.' + el.className.trim().replace(/\s+/g,'.');
        path.unshift(s);
        el = el.parentNode;
    }
    return path.join(' > ');
}
