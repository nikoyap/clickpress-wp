let feedbackMode = false;
let selectedElement = null;

const btn = document.createElement('button');
btn.innerText = 'Feedback';
btn.id = 'cuf-feedback-btn';

document.body.appendChild(btn);

btn.addEventListener('click', () => {

    feedbackMode = !feedbackMode;

    btn.innerText = feedbackMode
        ? 'Click Anywhere'
        : 'Feedback';

});

document.addEventListener('click', function(e) {

    if (!feedbackMode) return;

    if (e.target.id === 'cuf-feedback-btn') return;

    e.preventDefault();
    e.stopPropagation();

    selectedElement = e.target;

    selectedElement.classList.add('cuf-highlight');

    const comment = prompt('Enter feedback');

    if (!comment) {
        selectedElement.classList.remove('cuf-highlight');
        return;
    }

    const payload = {
        comment: comment,
        url: window.location.href,
        selector: getSelector(selectedElement),
        browser: navigator.userAgent
    };

    fetch(cufData.restUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': cufData.nonce
        },
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message || 'Feedback sent.');
    })
    .catch(err => {
        console.error(err);
        alert('Error sending feedback.');
    });

    selectedElement.classList.remove('cuf-highlight');

    feedbackMode = false;
    btn.innerText = 'Feedback';

}, true);

function getSelector(el) {

    if (el.id) {
        return '#' + el.id;
    }

    let path = [];

    while (el && el.nodeType === Node.ELEMENT_NODE) {

        let selector = el.nodeName.toLowerCase();

        if (el.className) {
            selector += '.' + el.className
                .trim()
                .replace(/\s+/g, '.');
        }

        path.unshift(selector);

        el = el.parentNode;
    }

    return path.join(' > ');
}
