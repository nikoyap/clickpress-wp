<?php
/*
Plugin Name: ClickUp Feedback
Plugin URI: https://example.com
Description: Visual website feedback tool that creates ClickUp tasks from frontend comments.
Version: 0.1.0
Author: WonderWave
License: GPL2
*/

if (!defined('ABSPATH')) exit;

define('CUF_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CUF_PLUGIN_PATH', plugin_dir_path(__FILE__));

require_once CUF_PLUGIN_PATH . 'includes/rest-api.php';

function cuf_enqueue_assets() {

    wp_enqueue_style(
        'cuf-style',
        CUF_PLUGIN_URL . 'public/css/feedback.css',
        [],
        '0.1.0'
    );

    wp_enqueue_script(
        'cuf-feedback',
        CUF_PLUGIN_URL . 'public/js/feedback.js',
        [],
        '0.1.0',
        true
    );

    wp_localize_script('cuf-feedback', 'cufData', [
        'restUrl' => rest_url('cuf/v1/feedback'),
        'nonce'   => wp_create_nonce('wp_rest')
    ]);
}

add_action('wp_enqueue_scripts', 'cuf_enqueue_assets');
