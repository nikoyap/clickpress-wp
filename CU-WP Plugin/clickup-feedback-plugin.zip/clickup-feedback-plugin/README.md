# ClickUp Feedback Plugin

## Installation

1. Upload the plugin zip to WordPress
2. Activate the plugin
3. Edit:
   includes/rest-api.php

Replace:
- YOUR_CLICKUP_API_KEY
- YOUR_LIST_ID

## Features

- Floating feedback button
- Click element feedback
- Sends task to ClickUp
- Captures:
  - URL
  - CSS selector
  - Browser info

## Next Steps

- Add screenshot support
- Add modal UI
- Add Elementor detection
- Add settings page
- Add annotations
