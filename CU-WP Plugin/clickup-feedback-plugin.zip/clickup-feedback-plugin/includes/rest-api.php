<?php

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {

    register_rest_route('cuf/v1', '/feedback', [
        'methods'  => 'POST',
        'callback' => 'cuf_submit_feedback',
        'permission_callback' => '__return_true'
    ]);

});

function cuf_submit_feedback($request) {

    $params = $request->get_json_params();

    $comment = sanitize_text_field($params['comment'] ?? '');
    $url = esc_url_raw($params['url'] ?? '');
    $selector = sanitize_text_field($params['selector'] ?? '');
    $browser = sanitize_text_field($params['browser'] ?? '');

    // TODO:
    // Replace with your real ClickUp API token and List ID
    $api_key = 'YOUR_CLICKUP_API_KEY';
    $list_id = 'YOUR_LIST_ID';

    $payload = [
        'name' => 'Website Feedback',
        'description' =>
            "Comment: {$comment}\n\n" .
            "Page URL: {$url}\n\n" .
            "Element: {$selector}\n\n" .
            "Browser: {$browser}"
    ];

    $response = wp_remote_post(
        "https://api.clickup.com/api/v2/list/{$list_id}/task",
        [
            'headers' => [
                'Authorization' => $api_key,
                'Content-Type'  => 'application/json'
            ],
            'body' => json_encode($payload)
        ]
    );

    if (is_wp_error($response)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $response->get_error_message()
        ], 500);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Feedback submitted successfully.'
    ], 200);
}
